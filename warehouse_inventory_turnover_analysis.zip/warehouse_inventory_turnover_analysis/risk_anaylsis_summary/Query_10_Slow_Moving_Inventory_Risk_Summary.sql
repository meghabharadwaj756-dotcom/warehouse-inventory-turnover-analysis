WITH slow_inventory AS (
    SELECT
        item_id,
        category,
        stock_level * holding_cost_per_unit_day
            AS daily_holding_cost,
        stockout_count_last_month
    FROM warehouse_inventory
    WHERE turnover_ratio <= 2
),
risk_analysis AS (
    SELECT *,
        CASE
            WHEN daily_holding_cost >= 500
                 AND stockout_count_last_month >= 5
                THEN 'High Priority'
            WHEN stockout_count_last_month >= 5
                THEN 'Stockout Review'
            WHEN daily_holding_cost >= 500
                THEN 'Holding Cost Review'
            ELSE 'Monitor'
        END AS investigation_priority
    FROM slow_inventory
)
SELECT
    investigation_priority,
    COUNT(*) AS item_count,
    ROUND(SUM(daily_holding_cost)::numeric, 2)
        AS total_daily_holding_cost,
    SUM(stockout_count_last_month) AS total_stockouts
FROM risk_analysis
GROUP BY investigation_priority
ORDER BY total_daily_holding_cost DESC;