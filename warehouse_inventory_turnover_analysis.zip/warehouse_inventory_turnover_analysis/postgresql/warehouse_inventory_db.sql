

-- WAREHOUSE INVENTORY TURNOVER PROJECT
-- SQL ANALYSIS: INVENTORY AND SLOW-MOVING STOCK
-- Purpose: Identify slow-moving items, holding costs, and stockout risks

-- Query 1: Count Total Inventory Records

SELECT COUNT(*) AS total_rows
FROM warehouse_inventory;

-- Query 2: Identify the 10 Lowest-Turnover Items

SELECT
    item_id,
    category,
    stock_level,
    daily_demand,
    turnover_ratio
FROM warehouse_inventory
ORDER BY turnover_ratio ASC
LIMIT 10;

-- Query 3: Count Slow-Moving Items by Category

SELECT
    category,
    COUNT(*) AS slow_moving_items
FROM warehouse_inventory
WHERE turnover_ratio <= 2
GROUP BY category
ORDER BY slow_moving_items DESC;

-- Query 4: Calculate Slow-Moving Inventory Percentage by Category
SELECT
    category,
    COUNT(*) AS total_items,
    SUM(
        CASE
            WHEN turnover_ratio <= 2 THEN 1
            ELSE 0
        END
    ) AS slow_moving_items,
    ROUND(
        100.0 * SUM(
            CASE
                WHEN turnover_ratio <= 2 THEN 1
                ELSE 0
            END
        ) / COUNT(*),
        2
    ) AS slow_moving_percentage
FROM warehouse_inventory
GROUP BY category
ORDER BY slow_moving_percentage DESC;

-- Query 5: Identify Items with the Highest Days of Stock

SELECT
    item_id,
    category,
    stock_level,
    daily_demand,
    ROUND(
        stock_level::NUMERIC / NULLIF(daily_demand, 0),
        2
    ) AS days_of_stock
FROM warehouse_inventory
WHERE daily_demand > 0
ORDER BY days_of_stock DESC
LIMIT 10;
 
-- Query 6: Identify Slow-Moving Items with the Highest Days of Stock

SELECT
    item_id,
    category,
    stock_level,
    daily_demand,
    turnover_ratio,
    ROUND(
        stock_level::NUMERIC / NULLIF(daily_demand, 0),
        2
    ) AS days_of_stock
FROM warehouse_inventory
WHERE daily_demand > 0
  AND turnover_ratio <= 2
ORDER BY days_of_stock DESC
LIMIT 10;

-- Query 7: Calculate Estimated Daily Holding Cost for Slow-Moving Items

SELECT
    item_id,
    category,
    stock_level,
    turnover_ratio,
    holding_cost_per_unit_day,
    ROUND(
        stock_level * holding_cost_per_unit_day,
        2
    ) AS estimated_daily_holding_cost
FROM warehouse_inventory
WHERE turnover_ratio <= 2
ORDER BY estimated_daily_holding_cost DESC
LIMIT 10;

-- Query 8: Analyze Slow-Moving Items with High Holding Costs and Stockouts

SELECT
    item_id,
    category,
    stock_level,
    turnover_ratio,
    ROUND(
        stock_level::NUMERIC / NULLIF(daily_demand, 0),
        2
    ) AS days_of_stock,
    ROUND(
        stock_level * holding_cost_per_unit_day,
        2
    ) AS daily_holding_cost,
    stockout_count_last_month
FROM warehouse_inventory
WHERE turnover_ratio <= 2
  AND daily_demand > 0
ORDER BY
    stock_level::NUMERIC / NULLIF(daily_demand, 0) DESC,
    stock_level * holding_cost_per_unit_day DESC
LIMIT 10;


-- Query 9: Summarize Total Stock Units and Daily Holding Cost
SELECT
    COUNT(*) AS slow_moving_items,
    SUM(stock_level) AS total_stock_units,
    ROUND(
        SUM(stock_level * holding_cost_per_unit_day),
        2
    ) AS total_daily_holding_cost
FROM warehouse_inventory
WHERE turnover_ratio <= 2;

-- Query 10: Compare Slow-Moving Inventory Holding Cost by Category
SELECT
    category,
    COUNT(*) AS slow_moving_items,
    SUM(stock_level) AS total_stock_units,
    ROUND(
        SUM(stock_level * holding_cost_per_unit_day),
        2
    ) AS daily_holding_cost
FROM warehouse_inventory
WHERE turnover_ratio <= 2
GROUP BY category
ORDER BY daily_holding_cost DESC;

-- Query 11: Repeat Category-Wise Holding Cost Analysis

SELECT
    category,
    COUNT(*) AS slow_moving_items,
    SUM(stock_level) AS total_stock_units,
    ROUND(
        SUM(stock_level * holding_cost_per_unit_day),
        2
    ) AS daily_holding_cost
FROM warehouse_inventory
WHERE turnover_ratio <= 2
GROUP BY category
ORDER BY daily_holding_cost DESC;

-- Query 12: Analyze Category-Wise Holding Costs, Turnover, and Stockouts
SELECT
    category,
    COUNT(*) AS slow_moving_items,
    SUM(stock_level) AS total_stock_units,
    ROUND(
        SUM(stock_level * holding_cost_per_unit_day), 2
    ) AS daily_holding_cost,
    SUM(stockout_count_last_month) AS total_stockouts,
    ROUND(
        AVG(stockout_count_last_month), 2
    ) AS avg_stockouts_per_item,
    ROUND(AVG(turnover_ratio), 2) AS avg_turnover_ratio
FROM warehouse_inventory
WHERE turnover_ratio <= 2
GROUP BY category
ORDER BY daily_holding_cost DESC;

-- Query 13: Identify Slow-Moving Items with Frequent Stockouts
SELECT
    item_id,
    category,
    stock_level,
    turnover_ratio,
    stockout_count_last_month,
    ROUND(
        stock_level * holding_cost_per_unit_day, 2
    ) AS daily_holding_cost,
    ROUND(
        stock_level::NUMERIC / NULLIF(daily_demand, 0), 2
    ) AS days_of_stock,
    lead_time_days,
    reorder_point
FROM warehouse_inventory
WHERE turnover_ratio <= 2
  AND stockout_count_last_month >= 5
ORDER BY daily_holding_cost DESC,
         stockout_count_last_month DESC
LIMIT 20;

-- Query 14: Calculate Correlation Between Holding Cost and Stockouts

SELECT
    COUNT(*) AS items_analysed,
    ROUND(
        CORR(
            stock_level * holding_cost_per_unit_day,
            stockout_count_last_month
        )::NUMERIC, 3
    ) AS holding_cost_stockout_correlation
FROM warehouse_inventory
WHERE turnover_ratio <= 2;

-- Query 15: Analyze Holding Cost and Stockout Correlation by Category

SELECT
    category,
    COUNT(*) AS items_analysed,
    ROUND(
        CORR(
            stock_level * holding_cost_per_unit_day,
            stockout_count_last_month
        )::NUMERIC, 3
    ) AS holding_cost_stockout_correlation,
    ROUND(
        AVG(stockout_count_last_month), 2
    ) AS avg_stockouts,
    ROUND(
        AVG(stock_level * holding_cost_per_unit_day), 2
    ) AS avg_daily_holding_cost
FROM warehouse_inventory
WHERE turnover_ratio <= 2
GROUP BY category
ORDER BY holding_cost_stockout_correlation DESC NULLS LAST;

- Query 16: Classify Slow-Moving Items by Investigation Priority
SELECT
    item_id,
    category,
    stock_level,
    turnover_ratio,
    stockout_count_last_month,
    ROUND(
        stock_level * holding_cost_per_unit_day, 2
    ) AS daily_holding_cost,
    CASE
        WHEN stockout_count_last_month >= 5
             AND stock_level * holding_cost_per_unit_day >= 500
            THEN 'High Priority'
        WHEN stockout_count_last_month >= 5
            THEN 'Stockout Review'
        WHEN stock_level * holding_cost_per_unit_day >= 500
            THEN 'Holding Cost Review'
        ELSE 'Monitor'
    END AS investigation_priority
FROM warehouse_inventory
WHERE turnover_ratio <= 2
ORDER BY
    CASE
        WHEN stockout_count_last_month >= 5
             AND stock_level * holding_cost_per_unit_day >= 500
            THEN 1
        WHEN stockout_count_last_month >= 5
            THEN 2
        WHEN stock_level * holding_cost_per_unit_day >= 500
            THEN 3
        ELSE 4
    END,
    stockout_count_last_month DESC,
    daily_holding_cost DESC;

	WITH inventory_risk AS (
    SELECT
        CASE
            WHEN stockout_count_last_month >= 5
             AND stock_level * holding_cost_per_unit_day >= 500
                THEN 'High Priority'
            WHEN stockout_count_last_month >= 5
                THEN 'Stockout Review'
            WHEN stock_level * holding_cost_per_unit_day >= 500
                THEN 'Holding Cost Review'
            ELSE 'Monitor'
        END AS investigation_priority
    FROM warehouse_inventory
    WHERE turnover_ratio <= 2
)

-- Query 17: Summarize Inventory Risk Categories Using a CTE
SELECT
    investigation_priority,
    COUNT(*) AS item_count
FROM inventory_risk
GROUP BY investigation_priority
ORDER BY item_count DESC;

-- Query 18: List Tables in the Public Database Schema

SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_type = 'BASE TABLE'
ORDER BY table_name;

-- Query 19: Rank Slow-Moving Items by Daily Holding Cost

SELECT
    item_id,
    category,
    stock_level,
    turnover_ratio,
    stockout_count_last_month,
    ROUND(
        (stock_level * holding_cost_per_unit_day)::numeric,
        2
    ) AS daily_holding_cost,
    RANK() OVER (
        ORDER BY
            stock_level * holding_cost_per_unit_day DESC
    ) AS holding_cost_rank
FROM warehouse_inventory
WHERE turnover_ratio <= 2
ORDER BY daily_holding_cost DESC
LIMIT 10;

-- Query 20: Summarize Slow-Moving Inventory Risk by Category

SELECT
    category,
    COUNT(*) AS slow_moving_items,
    ROUND(
        SUM(stock_level * holding_cost_per_unit_day)::numeric,
        2
    ) AS total_daily_holding_cost,
    ROUND(
        AVG(turnover_ratio)::numeric,
        2
    ) AS avg_turnover_ratio,
    SUM(stockout_count_last_month) AS total_stockouts
FROM warehouse_inventory
WHERE turnover_ratio <= 2
GROUP BY category
ORDER BY total_daily_holding_cost DESC;